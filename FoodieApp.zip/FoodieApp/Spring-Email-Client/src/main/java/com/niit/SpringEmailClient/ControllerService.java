package com.niit.SpringEmailClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.mail.MessagingException;
import java.util.Random;

@RestController
@RequestMapping("api/v1.6")
//@CrossOrigin(origins = "*")
public class ControllerService {

    @Autowired
    EmailSenderService service;

    @PostMapping("/email/{mail}")
    public ResponseEntity<?> otp(@RequestBody String body, @PathVariable String mail) throws MessagingException {

        System.out.printf(body+" | "+ mail);

        service.sendSimpleEmail("shaikhsadique414@gmail.com",
                "Mail from : "+mail+"\n"+body,
                "Foodie Application User FeedBack ");


        return new ResponseEntity<>(body, HttpStatus.OK);
    }
}



//        Random rand = new Random();
//        // Obtain a number between [0 - 49].
//        int n = rand.nextInt(9999);

//        service.sendSimpleEmail("foodieappdemo@gmail.com",
//                "your otp is "+n,
//                "OTP For Your Foodie Application");
