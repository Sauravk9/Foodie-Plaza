package com.niit.SpringEmailClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmailClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
