package com.project.admin1.proxy;

import com.project.admin1.model.UserAdmin;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "user-authentication-application", url = "localhost:8085")
public interface UserAdminProxy {
    @PostMapping("/api/v1.1/viewtube/save/user")
    public ResponseEntity insert(@RequestBody UserAdmin userAdmin);
}
