package com.project.admin1.controller;

import com.project.admin1.exception.UserAdminAlreadyExistException;
import com.project.admin1.model.Food;
import com.project.admin1.model.Restaurant;
import com.project.admin1.model.UserAdmin;
//import com.project.admin1.proxy.UserAdminProxy;
import com.project.admin1.proxy.UpdateRestaurantProxy;
import com.project.admin1.proxy.UserAdminProxy;
import com.project.admin1.service.UserAdminService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1.3/")
public class UserAdminController {

     UpdateRestaurantProxy updateRestaurantProxy;
     UserAdminService userAdminService;
    private ResponseEntity<?> responseEntity;
    private UserAdminProxy userAdminProxy;

    @Autowired
    public UserAdminController(UserAdminService userAdminService, UserAdminProxy userAdminProxy,UpdateRestaurantProxy updateRestaurantProxy) {
        this.userAdminService = userAdminService;
        this.userAdminProxy = userAdminProxy;
        this.updateRestaurantProxy = updateRestaurantProxy;
    }


//    @Autowired
//    public UserAdminController(UserAdminService userAdminService) {
//        this.userAdminService = userAdminService;
//    }

    @SneakyThrows
    @PostMapping("/register/userAdmin")
    public ResponseEntity<?> registerNewUser(@RequestBody UserAdmin userAdmin) {
        try {
            userAdminProxy.insert(userAdmin);
            responseEntity =  new ResponseEntity<>(userAdminService.registerNewUser(userAdmin), HttpStatus.CREATED);
        }
        catch(UserAdminAlreadyExistException e)
        {
            throw new UserAdminAlreadyExistException();
        }
        return responseEntity;
    }

    @GetMapping("admin/{city}")
    public ResponseEntity<?> getALlRestaurantByCity(@PathVariable String city){
        responseEntity = new ResponseEntity(userAdminService.findAllCity(city), HttpStatus.OK);
        return responseEntity;
    }

    @PostMapping("admin/{email}")
    public ResponseEntity<?> addRestaurant(@RequestBody Restaurant restaurant, @PathVariable String email){
        responseEntity = new ResponseEntity(userAdminService.addRestaurant(restaurant,email), HttpStatus.CREATED);
        return responseEntity;
    }

    @PostMapping("owner/{email}/{restName}")
    public ResponseEntity<?> addFoodInRest(@RequestBody Food food, @PathVariable String restName, @PathVariable String email){
        responseEntity = new ResponseEntity(userAdminService.addFoodInRestaurant(email,restName,food), HttpStatus.CREATED);
        return  responseEntity;
    }

    @GetMapping("admin/get")
    public ResponseEntity<?> getAllUserAdmin(){
        responseEntity =new ResponseEntity<>(userAdminService.getAllUser(), HttpStatus.OK);
        return responseEntity;
    }

    @GetMapping("admin/restaurant/{restName}")
    public ResponseEntity<?> getRestaurant(@PathVariable String restName){
        responseEntity = new ResponseEntity<>(userAdminService.getRestaurantDetails(restName), HttpStatus.OK);
        System.out.println(responseEntity);
        return responseEntity;
    }

    @PostMapping("admin/{restId}/{status}/update")
    public ResponseEntity<?> updateRestaurant(@PathVariable String restId,@PathVariable String status){
        responseEntity=new ResponseEntity<>(userAdminService.updateRestaurant(restId,status),HttpStatus.OK);
        updateRestaurantProxy.updateRestaurant(restId,status);
        return responseEntity;
    }

    @PostMapping("admin/restType/{type}")
    public ResponseEntity<?> sortAllRestaurantByType(@RequestBody List<Restaurant> restaurantList,@PathVariable String type){
        responseEntity = new ResponseEntity<>(userAdminService.sortAllRestaurantByType(restaurantList,type), HttpStatus.OK);
        return responseEntity;
    }

    @GetMapping("admin/low/{restname}")
    public ResponseEntity<?> sortAllFoodByLowPrice(@PathVariable String restname){
        responseEntity = new ResponseEntity<>(userAdminService.sortAllFoodByLowPrice(restname), HttpStatus.OK);
        return responseEntity;
    }
    @GetMapping("admin/high/{restname}")
    public ResponseEntity<?> sortAllFoodByHighPrice(@PathVariable String restname){
        responseEntity = new ResponseEntity<>(userAdminService.sortAllFoodByHighPrice(restname), HttpStatus.OK);
        return responseEntity;
    }

    @GetMapping("admin/cuisine/{restname}")
    public ResponseEntity<?> sortAllFoodByCuisine(@PathVariable String restname){
        responseEntity = new ResponseEntity<>(userAdminService.sortAllFoodByCuisine(restname), HttpStatus.OK);
        return responseEntity;
    }

    @GetMapping("admin/display")
    public ResponseEntity<?> approve(){
        responseEntity = new ResponseEntity<>(userAdminService.displayAllRestaurant(), HttpStatus.OK);
        System.out.println(userAdminService.displayAllRestaurant());
        return responseEntity;
    }
}
