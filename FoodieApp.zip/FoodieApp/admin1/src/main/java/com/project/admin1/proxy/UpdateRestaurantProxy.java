package com.project.admin1.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@FeignClient(name = "user-restaurant-service", url = "localhost:8082")
public interface UpdateRestaurantProxy {
    @PostMapping("api/v1.4/owner/{restId}/{status}/update")
    public ResponseEntity updateRestaurant(@PathVariable String restId, @PathVariable String status);
}
