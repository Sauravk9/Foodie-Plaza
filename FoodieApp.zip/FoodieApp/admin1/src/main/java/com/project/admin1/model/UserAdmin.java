package com.project.admin1.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Set;

@Document
@Data
public class UserAdmin {
    @Id
    private String email;
    private String password;
    private String name;
    private String typeOfUser;
    private String imgUrl;
//    private List<Restaurant> restaurantList;
    private Set<Restaurant> restaurantList;
}
