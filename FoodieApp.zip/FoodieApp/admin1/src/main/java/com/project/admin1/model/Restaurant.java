package com.project.admin1.model;

import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class Restaurant {
    private String restaurantName;
    private String type;
    private String city;
    private String status;
    private String imgUrl;
//    List<Food> foodList;
    private Set<Food> foodList;
}
