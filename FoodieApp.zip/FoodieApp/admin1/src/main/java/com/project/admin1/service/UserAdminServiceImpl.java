package com.project.admin1.service;

import com.project.admin1.exception.UserAdminAlreadyExistException;
import com.project.admin1.model.Food;
import com.project.admin1.model.Restaurant;
import com.project.admin1.model.UserAdmin;
import com.project.admin1.repository.UserAdminRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserAdminServiceImpl implements UserAdminService {
    @Autowired
    UserAdminRepository userAdminRepository;

    String emailId = "admin@gmail.com";

    @Override
    public UserAdmin registerNewUser(UserAdmin userAdmin) throws UserAdminAlreadyExistException {
        if (userAdminRepository.findById(userAdmin.getEmail()).isPresent()){
            throw new UserAdminAlreadyExistException();
        }
//        emailId = userAdmin.getEmail();
        return userAdminRepository.save(userAdmin);
    }

    @Override
    public List<Restaurant> findAllCity(String city) {
//    public Set<Restaurant> findAllCity(String city) {
        Set<Restaurant> restaurantList = userAdminRepository.findById(emailId).get().getRestaurantList();
//        Set<Restaurant> restaurantList = userAdminRepository.findById(emailId).get().getRestaurantList();
        for (Restaurant r: restaurantList){
            System.out.println(r);
        }
        List<Restaurant> resList=restaurantList.stream().filter(p->p.getStatus().equals("approved")).filter(p->p.getCity().toLowerCase(Locale.ROOT).contains(city.toLowerCase())).toList();
//        Set<Restaurant> resList=restaurantList.stream().filter(p->p.getCity().equalsIgnoreCase(city)).filter(p->p.isStatus()==true).collect(Collectors.toSet());
        return resList;
    }
    @Override
    public UserAdmin addRestaurant(Restaurant restaurant, String email) {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Set<Restaurant> restaurantList;
        if(u.getRestaurantList()==null) {
//            u.setRestaurantList(Arrays.asList(restaurant));
//            u.setRestaurantList((Set<Restaurant>) Arrays.asList(restaurant));
            restaurantList = new HashSet<>();
        }
        else {
//            List<Restaurant> restaurantList=u.getRestaurantList();
            restaurantList = u.getRestaurantList();
        }
        restaurantList.add(restaurant);
        u.setRestaurantList(restaurantList);
        return userAdminRepository.save(u);
    }

    @Override
    public UserAdmin addFoodInRestaurant(String email, String restId, Food food){
        UserAdmin u = userAdminRepository.findById(emailId).get();

        Set<Restaurant> restaurantList=u.getRestaurantList();
        Restaurant res=restaurantList.stream().filter(p->p.getRestaurantName().equals(restId)).toList().get(0);
        restaurantList.removeIf(p->p.getRestaurantName().equals(restId));
        Set<Food> foodList;
        if(res.getFoodList()==null){
            foodList = new HashSet<>();
        }
        else {
//            List<Food> foodList=res.getFoodList();
            foodList = res.getFoodList();
        }
        foodList.add(food);
        res.setFoodList(foodList);
        restaurantList.add(res);
        u.setRestaurantList(restaurantList);
        return userAdminRepository.save(u);
    }

    @Override
    public UserAdmin getAllUser() {
        return userAdminRepository.findById(emailId).get();
    }

    @Override
    public Restaurant getRestaurantDetails(String restName) {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Restaurant restaurant = u.getRestaurantList().stream().filter(p->p.getRestaurantName().equals(restName)).toList().get(0);
        System.out.println(restaurant);
        return restaurant;
    }

    @Override
    public UserAdmin updateRestaurant(String restId, String status) {
        UserAdmin user=userAdminRepository.findById(emailId).get();

//        List<Restaurant> restaurantList=user.getRestaurantList();
        Set<Restaurant> restaurantList=user.getRestaurantList();
        Restaurant restaurant=restaurantList.stream().filter(p->p.getRestaurantName().equals(restId)).toList().get(0);
        restaurant.setStatus(status);
        restaurantList.removeIf(p->p.getRestaurantName().equals(restId));
        restaurantList.add(restaurant);
        user.setRestaurantList(restaurantList);
        return userAdminRepository.save(user);
    }

    @Override
    public List<Food> sortAllFoodByCuisine(String restName) {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Set<Restaurant> restaurantList = u.getRestaurantList();
        List<Restaurant> rest = restaurantList.stream().filter(p-> p.getStatus().equals("approved")).filter(n -> n.getRestaurantName().equals(restName)).toList();
        Restaurant restaurant = rest.get(0);
        Set<Food> foods = restaurant.getFoodList();
//        for (Restaurant r: restaurantList){
//            foods = r.getFoodList();
//        }
        return foods.stream().sorted(Comparator.comparing(Food::getFoodName)).collect(Collectors.toList());
//        return foods.stream().sorted((p1, p2) -> p1.getCuisine().compareTo(p2.getCuisine())).collect(Collectors.toList());
//        return foods.stream().sorted(Comparator.comparing(Food::getCuisine)).collect(Collectors.toList());
    }

    @Override
    public List<Food> sortAllFoodByLowPrice(String restName) {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Set<Restaurant> restaurantList = u.getRestaurantList();
        List<Restaurant> rest = restaurantList.stream().filter(n -> n.getRestaurantName().equals(restName)).filter(p-> p.getStatus().equals("approved")).toList();
        Restaurant restaurant = rest.get(0);
        Set<Food> foods = restaurant.getFoodList();

        return foods.stream().sorted(Comparator.comparing(Food::getPrice)).collect(Collectors.toList());
//        return foods.stream().sorted((p1, p2) -> p1.getPrice().compareTo(p2.getPrice())).collect(Collectors.toList());
    }
    @Override
    public List<Food> sortAllFoodByHighPrice(String restName) {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Set<Restaurant> restaurantList = u.getRestaurantList();
        List<Restaurant> rest = restaurantList.stream().filter(n -> n.getRestaurantName().equals(restName)).filter(p->p.getStatus().equals("approved")).toList();
        Restaurant restaurant = rest.get(0);
        Set<Food> foods = restaurant.getFoodList();

        return foods.stream().sorted(Comparator.comparing(Food::getPrice).reversed()).collect(Collectors.toList());
//        return foods.stream().sorted((p1, p2) -> p1.getPrice().compareTo(p2.getPrice())).collect(Collectors.toList());
    }

    @Override
        public List<Restaurant> sortAllRestaurantByType(List<Restaurant> restaurantList,String type) {
//        UserAdmin u = userAdminRepository.findById(emailId).get();
//        Set<Restaurant> restaurantList = u.getRestaurantList();
//        restaurantList.stream().sorted((p1, p2) -> p1.getType().compareTo(p2.getType())).toList();
        return restaurantList.stream().filter(p->p.getStatus().equals("approved")).filter(p->p.getType().equalsIgnoreCase(type)).toList();
    }

    @Override
    public List<Restaurant> displayAllRestaurant() {
        UserAdmin u = userAdminRepository.findById(emailId).get();
        Set<Restaurant> restaurantList = u.getRestaurantList();

        return restaurantList.stream().toList();
    }


}
