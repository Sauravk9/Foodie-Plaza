package com.project.admin1.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.CONFLICT, reason = "These restaurant name is already present...!")
public class UserAdminAlreadyExistException extends Exception{
}
