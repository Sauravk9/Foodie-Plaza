package com.project.admin1;

import com.project.admin1.model.UserAdmin;
import com.project.admin1.repository.UserAdminRepository;
import com.project.admin1.service.UserAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableEurekaClient
@EnableFeignClients
public class Admin1Application {

	@Autowired
	UserAdminRepository userAdminRepository;

	public static void main(String[] args) {
		UserAdmin userAdmin = new UserAdmin();
		userAdmin.setEmail("admin@gmail.com");
		userAdmin.setName("admin");
		userAdmin.setTypeOfUser("admin");
		userAdmin.setPassword("admin123");
		userAdmin.setImgUrl("assets/avatar3.jpg");


		SpringApplication.run(Admin1Application.class, args);

	}

}
