package com.project.admin1.service;

import com.project.admin1.exception.UserAdminAlreadyExistException;
import com.project.admin1.model.Food;
import com.project.admin1.model.Restaurant;
import com.project.admin1.model.UserAdmin;

import java.util.List;
import java.util.Set;

public interface UserAdminService {
    UserAdmin registerNewUser(UserAdmin userAdmin) throws UserAdminAlreadyExistException;

    List<Restaurant> findAllCity(String city);

    UserAdmin addRestaurant(Restaurant restaurant,String email);

    UserAdmin addFoodInRestaurant(String email, String restId, Food food);

    UserAdmin getAllUser();

    Restaurant getRestaurantDetails(String restName);

    UserAdmin updateRestaurant(String restId,String status);

    List<Food> sortAllFoodByCuisine(String restName);

    List<Food> sortAllFoodByLowPrice(String restName);

    List<Food> sortAllFoodByHighPrice(String restName);

    List<Restaurant> sortAllRestaurantByType(List<Restaurant> restaurantList,String type);

    //to display all the restaurant with false status
    List<Restaurant> displayAllRestaurant();

//    List<Food> findAllFoodByCuisine(String restName);
//    List<Restaurant> sortAllRestaurantByRating();
}

// sorting of food by cuisine and price
// sorting of restaurant by type of restaurant and rating of the restaurant