package com.project.admin1.repository;

import com.project.admin1.model.UserAdmin;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface UserAdminRepository extends MongoRepository<UserAdmin, String> {
    @Query("{'restaurantList.city': ?0}")
    UserAdmin findAllCity(String city);


}
