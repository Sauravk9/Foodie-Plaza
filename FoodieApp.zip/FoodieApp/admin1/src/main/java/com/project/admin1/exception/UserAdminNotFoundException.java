package com.project.admin1.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "404 : These restaurant name is not found...!")
public class UserAdminNotFoundException extends Exception{
}
