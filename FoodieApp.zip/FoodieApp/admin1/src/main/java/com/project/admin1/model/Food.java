package com.project.admin1.model;

import lombok.Data;

@Data
public class Food {
    private String foodName;
    private String cuisine;
    private String price;
    private String imgUrl;
}
