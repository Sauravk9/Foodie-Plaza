package com.project.ApiGateway.config;

import com.project.ApiGateway.filter.JWTFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.CrossOrigin;

import javax.lang.model.util.Elements;

@Configuration
@CrossOrigin(origins = "*" )
public class AppConfig {
    @Bean
    public RouteLocator myRoutes(RouteLocatorBuilder builder)
    {
        return builder.routes()

                .route(p->p .path("/api/v1.1/viewtube/**") .uri("lb://user-authentication-application"))
                .route(p->p .path("/api/v1.2/**") .uri("lb://user-video-service"))
                .route(p->p.path("/api/v1.3/**").uri("lb://user-admin1-service"))
                .route(p-> p.path("/api/v1.4/**").uri("lb://user-restaurant-service"))
                .route(p-> p.path("/api/v1.6/**").uri("lb://spring-email-service"))
                .build();
    }

    @Bean
    public FilterRegistrationBean jwtFilterBean(){

        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();

        filterRegistrationBean.setFilter(new JWTFilter());
        System.out.println("I am going to the filter...!");
        filterRegistrationBean.addUrlPatterns("/api/v1.4/owner/**");
        filterRegistrationBean.addUrlPatterns("/api/v1.2/user/**");
        System.out.println("I came back form the filter...!");
        return filterRegistrationBean;
    }
}
