package com.project.UserAuthenticationService.service;

import com.project.UserAuthenticationService.exception.InvalidCredentialsException;
import com.project.UserAuthenticationService.exception.UserAlreadyExistsException;
import com.project.UserAuthenticationService.model.User;

public interface UserService {
    User saveUser(User user) throws UserAlreadyExistsException;

    User findByEmailAndPassword(User user) throws InvalidCredentialsException;
}
