package com.project.UserAuthenticationService.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class User {
    @Id
    String email;
    String password;
    String typeOfUser;
    String imgUrl;
}
