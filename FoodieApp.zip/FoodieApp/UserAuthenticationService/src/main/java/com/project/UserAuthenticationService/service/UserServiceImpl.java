package com.project.UserAuthenticationService.service;

import com.project.UserAuthenticationService.exception.InvalidCredentialsException;
import com.project.UserAuthenticationService.exception.UserAlreadyExistsException;
import com.project.UserAuthenticationService.model.User;
import com.project.UserAuthenticationService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserRepository userRepository;

    @Override
    public User saveUser(User user) throws UserAlreadyExistsException {
        if (userRepository.findById(user.getEmail()).isPresent()){
            throw new UserAlreadyExistsException();
        }
        return userRepository.save(user);
    }

    @Override
    public User findByEmailAndPassword(User user) throws InvalidCredentialsException {
        String email = user.getEmail();
        String password = user.getPassword();
        String isAdmin = user.getTypeOfUser();
        User loggedInUser = userRepository.findByEmailAndPassword(email,password);

        if (isAdmin.equalsIgnoreCase("admin2")){
            System.out.println("You are the admin...!");
        }
        else if (isAdmin.equalsIgnoreCase("admin2")){
            System.out.println("You are restaurant owner...!");
        }
        else {
            System.out.println("you are a normal user...!");
        }
        if (loggedInUser == null){
            throw new InvalidCredentialsException();
        }
        return loggedInUser;
    }
}
