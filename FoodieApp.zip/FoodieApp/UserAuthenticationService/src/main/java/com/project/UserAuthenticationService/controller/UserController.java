package com.project.UserAuthenticationService.controller;

import com.project.UserAuthenticationService.exception.InvalidCredentialsException;
import com.project.UserAuthenticationService.exception.UserAlreadyExistsException;
import com.project.UserAuthenticationService.model.User;
import com.project.UserAuthenticationService.security.JWTSecurityTokenGeneratorImpl;
import com.project.UserAuthenticationService.service.UserService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/v1.1/viewtube")
public class UserController {
    UserService userService;
    JWTSecurityTokenGeneratorImpl tokenGenerator;

    @Autowired
    public UserController(UserService userService, JWTSecurityTokenGeneratorImpl tokenGenerator) {
        this.userService = userService;
        this.tokenGenerator = tokenGenerator;
    }

    @PostMapping("/save/user")
    @SneakyThrows
    public ResponseEntity<?> insert(@RequestBody User user){
        try {
            userService.saveUser(user);
        }
        catch (UserAlreadyExistsException u){
            throw new UserAlreadyExistsException();
        }
        return new ResponseEntity<>("user created successfully...!", HttpStatus.CREATED);
    }

    @PostMapping("/login/user")
    @SneakyThrows
    public ResponseEntity<?> loginUser(@RequestBody User user){
        Map<String, String> userMap = null;

        User retirevedUser = userService.findByEmailAndPassword(user);
        System.out.println(retirevedUser);
        if (retirevedUser == null){
            throw new InvalidCredentialsException();
        }
        userMap = tokenGenerator.generateToken(user);

        return new ResponseEntity<>(userMap, HttpStatus.OK);
    }
}
