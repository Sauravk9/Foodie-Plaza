package com.project.UserAuthenticationService.security;

import com.project.UserAuthenticationService.model.User;

import java.util.Map;

public interface SecurityTokenGenerator {
    Map<String,String> generateToken(User user);
}
