package com.project.UserAuthenticationService.security;

import com.project.UserAuthenticationService.model.User;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class JWTSecurityTokenGeneratorImpl {
    public Map<String, String> generateToken(User user) {
// multiple claims for a token - 3 types - registered, public, and private

        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, 1);
        dt = c.getTime();

        String jwtToken = Jwts.builder().setIssuer("viewTube")
                .setSubject(user.getEmail())
                .setIssuedAt(new Date())
                .setExpiration(dt)
                .signWith(SignatureAlgorithm.HS256,"secretKey")
                //mysecret is the key that has to be shared everytime you do encrypt and decrypt process
                .compact();
        Map<String,String> map = new HashMap<>();
        map.put("token",jwtToken);
        map.put("message","Authentication Successful");
        return map;
    }
}
