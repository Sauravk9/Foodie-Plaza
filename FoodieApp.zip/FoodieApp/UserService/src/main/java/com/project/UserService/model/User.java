package com.project.UserService.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;
import java.util.Set;

@Document
@Data
public class User {
//    @Id
//    private String email;
//    private String userName;
//    private String password;
//    private String imgUrl;
//    private String address;
//    private String typeOfUser;
    @Id
    private String email;
    private String firstName;
    private String lastName;
    private String typeOfUser;
    private String password;
    private String phoneNumber;
    private String address;
    private String imgUrl;
    private Set<Restaurant> favorite;
    private Set<Food> favoriteFood;
    private Set<Food> food;
//    private List<Restaurant> favorite;
//    private List<Food> food;
}
