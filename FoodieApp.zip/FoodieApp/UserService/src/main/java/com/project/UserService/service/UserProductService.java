package com.project.UserService.service;

import com.project.UserService.exception.FoodNotFoundException;
import com.project.UserService.exception.UserAlreadyExistException;
import com.project.UserService.exception.UserNotFoundException;
import com.project.UserService.model.Food;
import com.project.UserService.model.Restaurant;
import com.project.UserService.model.User;

import java.util.List;

public interface UserProductService {

    User registerNewUser(User user) throws UserAlreadyExistException;

    User getUserDetails(String userEmail) throws UserNotFoundException;

    User addFoodInCart(String email, Food food) throws UserNotFoundException;

    User removeFoodFromCart(String email,String foodName) throws UserNotFoundException, FoodNotFoundException;

    User removeFoodFromFav(String email,String foodName) throws UserNotFoundException, FoodNotFoundException;

    User removeRetaurantFromFav(String email,String restName) throws UserNotFoundException, FoodNotFoundException;

    User removeAllFood(String email) throws UserNotFoundException;
    User addFavoriteRestaurant(String email, Restaurant restaurant) throws UserNotFoundException;

    User addFavoriteFood(String email, Food food) throws UserNotFoundException;

    List<Food> displayFoodFromCart(String email) throws UserNotFoundException;

    List<Food> displayFavoriteFood(String email) throws UserNotFoundException;

    List<Restaurant> displayFavoriteRestaurant(String email) throws UserNotFoundException;



}
