package com.project.UserService.model;

import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class Restaurant {
    private String restaurantName;
    private String type;
    private String city;
    private String status;
    private String imgUrl;
    private Set<Food> foodList;
//    List<Food> foodList;
}
