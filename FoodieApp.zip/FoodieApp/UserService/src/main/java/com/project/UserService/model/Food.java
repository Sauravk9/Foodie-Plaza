package com.project.UserService.model;

import lombok.Data;

@Data
public class Food {
    String foodName;
    String cuisine;
    String price;
    String imgUrl;
}
