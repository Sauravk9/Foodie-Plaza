package com.project.UserService.controller;

import com.project.UserService.exception.FoodNotFoundException;
import com.project.UserService.exception.UserAlreadyExistException;
import com.project.UserService.exception.UserNotFoundException;
import com.project.UserService.model.Food;
import com.project.UserService.model.Restaurant;
import com.project.UserService.model.User;
import com.project.UserService.proxy.UserProxy;
import com.project.UserService.service.UserProductService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1.2/")
public class UserVideoController {

    private UserProductService userProductService;
    private ResponseEntity<?> responseEntity;
    private UserProxy userProxy;

    @Autowired
    public UserVideoController(UserProductService userProductService, UserProxy userProxy) {
        this.userProductService = userProductService;
        this.userProxy = userProxy;
    }

    @SneakyThrows
    @PostMapping("/register")
    public ResponseEntity<?> registerNewUser(@RequestBody User user) {
        try {
            userProxy.insert(user);
            responseEntity =  new ResponseEntity<>(userProductService.registerNewUser(user), HttpStatus.CREATED);
        }
        catch(UserAlreadyExistException e)
        {
            throw new UserAlreadyExistException();
        }
        return responseEntity;
    }
    @SneakyThrows
    @GetMapping("/user/{email}")
    public ResponseEntity<?> getUserDetails(@PathVariable String email){
        try {
            responseEntity = new ResponseEntity<>(userProductService.getUserDetails(email),HttpStatus.OK);
        }
        catch (UserNotFoundException u){
            throw new UserNotFoundException();
        }
        return responseEntity;
    }
    @SneakyThrows
    @PostMapping("/user/{email}/add")
    public ResponseEntity<?> addFoodToCart(@RequestBody Food food,@PathVariable String email){
        try {
            responseEntity=new ResponseEntity<>(userProductService.addFoodInCart(email,food),HttpStatus.CREATED);
        }
        catch (UserNotFoundException u){
            throw new UserNotFoundException();
        }
        return responseEntity;
    }

    @SneakyThrows
    @PostMapping("/user/{email}/fav")
    public ResponseEntity<?> addFavRestaurant(@RequestBody Restaurant restaurant,@PathVariable String email){
        try {
            responseEntity=new ResponseEntity<>(userProductService.addFavoriteRestaurant(email,restaurant),HttpStatus.OK);
        }
        catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        }
        return responseEntity;
    }

    @SneakyThrows
    @DeleteMapping("/user/cart/{email}/{foodName}")
    public ResponseEntity<?> deleteFromCart(@PathVariable String email,@PathVariable String foodName){
        try {
            responseEntity=new ResponseEntity<>(userProductService.removeFoodFromCart(email,foodName),HttpStatus.OK);
        }catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        }catch (FoodNotFoundException f){
            throw new FoodNotFoundException();
        }
        return responseEntity;
    }

    @SneakyThrows
    @DeleteMapping("/user/food/{email}/{foodName}")
    public ResponseEntity<?> deleteFromFavorite(@PathVariable String email,@PathVariable String foodName){
        try {
            responseEntity=new ResponseEntity<>(userProductService.removeFoodFromFav(email,foodName),HttpStatus.OK);
        }catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        }
        catch (FoodNotFoundException f){
            throw new FoodNotFoundException();
        }
        return responseEntity;
    }

    @SneakyThrows
    @DeleteMapping("/user/rest/{email}/{restName}")
    public ResponseEntity<?> deleteFromRestaurantFavorite(@PathVariable String email,@PathVariable String restName){
        try {
            responseEntity=new ResponseEntity<>(userProductService.removeRetaurantFromFav(email,restName),HttpStatus.OK);
        }catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        }catch (FoodNotFoundException f){
            throw new FoodNotFoundException();
        }
        return responseEntity;
    }

    @SneakyThrows
    @DeleteMapping("/user/{email}/all")
    public ResponseEntity<?> deleteAllFromCart(@PathVariable String email){
        try {
            responseEntity=new ResponseEntity<>(userProductService.removeAllFood(email),HttpStatus.OK);
        }catch (UserNotFoundException u) {
            throw new UserNotFoundException();
        }
        return responseEntity;
    }
    @SneakyThrows
    @PostMapping("/user/{email}/favFood")
    public ResponseEntity<?> addFavoriteFood(@RequestBody Food food,@PathVariable String email){
        try {
            responseEntity=new ResponseEntity<>(userProductService.addFavoriteFood(email,food),HttpStatus.OK);
        }
        catch (UserNotFoundException u){
            throw new UserNotFoundException();
        }
        return responseEntity;
    }
    @SneakyThrows
    @GetMapping("user/{email}/cart")
    public ResponseEntity<?> displayFoodToCart(@PathVariable String email) {
        responseEntity=new ResponseEntity<>(userProductService.displayFoodFromCart(email),HttpStatus.OK);
        return responseEntity;
    }

    @SneakyThrows
    @GetMapping("user/{email}/favFood")
    public ResponseEntity<?> displayFavoriteFood(@PathVariable String email) {
        responseEntity=new ResponseEntity<>(userProductService.displayFavoriteFood(email),HttpStatus.OK);
        return responseEntity;
    }

    @SneakyThrows
    @GetMapping("user/{email}/favRes")
    public ResponseEntity<?> displayFavRes(@PathVariable String email) {
        responseEntity=new ResponseEntity<>(userProductService.displayFavoriteRestaurant(email),HttpStatus.OK);
        return responseEntity;
    }
}
