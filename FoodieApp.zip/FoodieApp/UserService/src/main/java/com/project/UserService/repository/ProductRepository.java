package com.project.UserService.repository;

import com.project.UserService.model.Food;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Food, String> {
}
