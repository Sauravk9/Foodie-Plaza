package com.project.UserService.service;

import com.project.UserService.exception.FoodNotFoundException;
import com.project.UserService.exception.UserAlreadyExistException;
import com.project.UserService.exception.UserNotFoundException;
import com.project.UserService.model.Food;
import com.project.UserService.model.Restaurant;
import com.project.UserService.model.User;
import com.project.UserService.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserProductServiceImpl implements UserProductService{
    @Autowired
    UserRepository userRepository;

    @Override
    public User registerNewUser(User user) throws UserAlreadyExistException {
        if (userRepository.findById(user.getEmail()).isPresent()){
            throw new UserAlreadyExistException();
        }
        return userRepository.save(user);
    }

    @Override
    public User getUserDetails(String userEmail) throws UserNotFoundException {
        List<User> userList = userRepository.findAll();
        User user = userList.stream().filter(p->p.getEmail().equals(userEmail)).toList().get(0);
        System.out.println(user);
        return user;
    }

    @Override
    public User addFoodInCart(String email, Food food) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(email).get();
        if(user.getFood()==null){
//            user.setFood(Arrays.asList(food));
            Set<Food> foodList = new HashSet<>();
            foodList.add(food);
            user.setFood(foodList);
        }
        else {
//            List<Food> foodList=user.getFood();
//            foodList.add(food);
//            user.setFood(foodList);

            Set<Food> foodList = user.getFood();
            foodList.add(food);
            user.setFood(foodList);
        }
        return userRepository.save(user);
    }

    @Override
    public User removeFoodFromCart(String email, String foodName) throws UserNotFoundException, FoodNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }

        User user=userRepository.findById(email).get();
//        List<Food> foodList=user.getFood();
        Set<Food> foodList=user.getFood();
        if(!foodList.removeIf(p->p.getFoodName().equals(foodName))){
            throw new FoodNotFoundException();
        }
        user.setFood(foodList);
        return userRepository.save(user);
    }

    @Override
    public User removeFoodFromFav(String email, String foodName) throws UserNotFoundException, FoodNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }

        User user=userRepository.findById(email).get();
//        List<Food> foodList=user.getFood();
        Set<Food> foodList=user.getFavoriteFood();

        if(!foodList.removeIf(p->p.getFoodName().equals(foodName))){
            throw new FoodNotFoundException();
        }
        user.setFavoriteFood(foodList);
        return userRepository.save(user);
    }

    @Override
    public User removeRetaurantFromFav(String email, String restName) throws UserNotFoundException, FoodNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }

        User user=userRepository.findById(email).get();
//        List<Food> foodList=user.getFood();
        Set<Restaurant> restaurants=user.getFavorite();
        if(!restaurants.removeIf(p->p.getRestaurantName().equals(restName))){
            throw new FoodNotFoundException();
        }
        user.setFavorite(restaurants);
        return userRepository.save(user);
    }

    @Override
    public User removeAllFood(String email) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }

        User user=userRepository.findById(email).get();
        Set<Food> foodSet=new HashSet<>();
        user.setFood(foodSet);
        return userRepository.save(user);
    }

    @Override
    public User addFavoriteRestaurant(String email, Restaurant restaurant) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(email).get();

        if(user.getFavorite()==null){
//            user.setFavorite(Arrays.asList(restaurant));
            Set<Restaurant> restaurantList = new HashSet<>();
            restaurantList.add(restaurant);
            user.setFavorite(restaurantList);
        }
        else {
//            List<Restaurant> restaurantList=user.getFavorite();
//            restaurantList.add(restaurant);
//            user.setFavorite(restaurantList);
            Set<Restaurant> restaurantList = user.getFavorite();
            restaurantList.add(restaurant);
            user.setFavorite(restaurantList);
        }
        return userRepository.save(user);
    }

    @Override
    public User addFavoriteFood(String email, Food food) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(email).get();
        if(user.getFavoriteFood()==null){
            Set<Food> foodSet=new HashSet<>();
            foodSet.add(food);
            user.setFavoriteFood(foodSet);
        }
        else {
            Set<Food> foodSet = user.getFavoriteFood();
            foodSet.add(food);
            user.setFavoriteFood(foodSet);
        }
        return userRepository.save(user);
    }

    @Override
    public List<Food> displayFoodFromCart(String email) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(email).get();
        List<Food> foodList=user.getFood().stream().toList();
        return foodList;
    }

    @Override
    public List<Food> displayFavoriteFood(String email) throws UserNotFoundException {
        if (userRepository.findById(email).isEmpty()) {
            throw new UserNotFoundException();
        }
        User user = userRepository.findById(email).get();
        List<Food> foodList = user.getFavoriteFood().stream().toList();
        return foodList;
    }

    @Override
    public List<Restaurant> displayFavoriteRestaurant(String email) throws UserNotFoundException {
        if(userRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User user=userRepository.findById(email).get();
        List<Restaurant> resList=user.getFavorite().stream().toList();
        return resList;
    }
}
