package com.project.Restaurant.controller;

import com.project.Restaurant.exception.UserAlreadyExistException;
import com.project.Restaurant.exception.UserNotFoundException;
import com.project.Restaurant.model.Food;
import com.project.Restaurant.model.Restaurant;
import com.project.Restaurant.model.User;
import com.project.Restaurant.proxy.AdminProxy;
import com.project.Restaurant.proxy.UserProxy;
import com.project.Restaurant.service.UserService;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.ws.rs.Path;

@RestController
@RequestMapping("api/v1.4/")
public class UserController {
    UserService userService;
    UserProxy userProxy;

    ResponseEntity responseEntity;

    @Autowired
    public UserController(UserService userService, UserProxy userProxy) {
        this.userService = userService;
        this.userProxy = userProxy;

    }
    @SneakyThrows
    @PostMapping("owner/")
    public ResponseEntity<?> register(@RequestBody User user){
        try{userProxy.insert(user);
            responseEntity = new ResponseEntity(userService.registerUser(user), HttpStatus.CREATED);
        }
        catch (UserAlreadyExistException u){
            throw new UserAlreadyExistException();
        }
        return responseEntity;
    }
    @SneakyThrows
    @PostMapping("owner/{email}")
    public ResponseEntity<?> addRestaurant(@RequestBody Restaurant restaurant, @PathVariable String email){
        responseEntity = new ResponseEntity(userService.addRestaurant(email,restaurant), HttpStatus.CREATED);
        return responseEntity;
    }
    @SneakyThrows
    @PostMapping("owner/{email}/{restName}")
    public ResponseEntity<?> addFoodInRest(@RequestBody Food food, @PathVariable String restName, @PathVariable String email){
        responseEntity = new ResponseEntity(userService.addFoodInRestaurant(email,restName,food), HttpStatus.CREATED);
        return  responseEntity;
    }
    @SneakyThrows
    @DeleteMapping("owner/{email}/{restName}/{foodName}")
    public ResponseEntity<?> deleteFoodInRestaurant(@PathVariable String email, @PathVariable String restName, @PathVariable String foodName){
        responseEntity = new ResponseEntity(userService.deleteFoodInRestaurant(email, restName, foodName), HttpStatus.OK);
        return responseEntity;
    }
    @GetMapping("owner/{city}")
    public ResponseEntity<?> getALlRestaurantByCity(@PathVariable String city){
        responseEntity = new ResponseEntity(userService.findAllCity(city), HttpStatus.OK);
        return responseEntity;
    }

    @PostMapping("owner/{restId}/{status}/update")
    public ResponseEntity<?> updateRestaurant(@PathVariable String restId, @PathVariable String status){
        responseEntity=new ResponseEntity<>(userService.updateRestaurant(restId,status),HttpStatus.OK);
        return responseEntity;
    }

    @SneakyThrows
    @GetMapping("/user/{email}")
    public ResponseEntity<?> getUserDetails(@PathVariable String email){
        try {
            responseEntity = new ResponseEntity<>(userService.getUserDetails(email),HttpStatus.OK);
        }
        catch (UserNotFoundException u){
            throw new UserNotFoundException();
        }
        return responseEntity;
    }

}
