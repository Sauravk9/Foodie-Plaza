package com.project.Restaurant.proxy;

import com.project.Restaurant.model.Food;
import com.project.Restaurant.model.Restaurant;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "user-admin1-service", url = "localhost:8083")
public interface AdminProxy {
    @PostMapping("/api/v1.3/admin/{email}")
    public ResponseEntity<?> addRestaurant(@RequestBody Restaurant restaurant, @PathVariable String email);

    @PostMapping("/api/v1.3/owner/{email}/{restName}")
    public ResponseEntity<?> addFoodInRest(@RequestBody Food food, @PathVariable String restName, @PathVariable String email);
}
