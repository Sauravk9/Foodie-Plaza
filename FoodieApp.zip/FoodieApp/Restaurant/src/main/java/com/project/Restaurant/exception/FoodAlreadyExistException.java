package com.project.Restaurant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.NOT_FOUND, reason = "Food already exist ..!")
public class FoodAlreadyExistException extends Exception{
}
