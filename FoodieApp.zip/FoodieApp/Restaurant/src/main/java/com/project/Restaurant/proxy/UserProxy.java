package com.project.Restaurant.proxy;

import com.project.Restaurant.model.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "user-authentication-application", url = "localhost:8085")
public interface UserProxy {
    @PostMapping("/api/v1.1/viewtube/save/user")
    public ResponseEntity insert(@RequestBody User user);
}
