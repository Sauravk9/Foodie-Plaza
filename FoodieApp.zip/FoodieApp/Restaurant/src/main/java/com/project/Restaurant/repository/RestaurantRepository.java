package com.project.Restaurant.repository;

import com.project.Restaurant.model.Restaurant;
import com.project.Restaurant.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface RestaurantRepository extends MongoRepository<User, String> {
    @Query("{'restaurants.city': ?0}")
    List<User> findAllCity(String city);
//    @Query("{'restaurants.status' : 'false'}")
//    List<User> findAllRestaurants();
}
