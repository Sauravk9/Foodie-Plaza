package com.project.Restaurant.service;

import com.project.Restaurant.exception.FoodNotFoundException;
import com.project.Restaurant.exception.RestaurantNotFoundException;
import com.project.Restaurant.exception.UserAlreadyExistException;
import com.project.Restaurant.exception.UserNotFoundException;
import com.project.Restaurant.model.Food;
import com.project.Restaurant.model.Restaurant;
import com.project.Restaurant.model.User;

import java.util.List;

public interface UserService {
    User registerUser(User user) throws UserAlreadyExistException;
    User addRestaurant(String email,Restaurant restaurant) throws UserNotFoundException;
    User addFoodInRestaurant(String email,String restId,Food food) throws UserNotFoundException, RestaurantNotFoundException;

    User deleteFoodInRestaurant(String email ,String rName,String foodName) throws UserNotFoundException, FoodNotFoundException;

    List<Restaurant> findAllCity(String city);

//    User updateFoodStatusInRestaurant();

    User updateRestaurant(String restId, String status);

    User getUserDetails(String userEmail) throws UserNotFoundException;
}
