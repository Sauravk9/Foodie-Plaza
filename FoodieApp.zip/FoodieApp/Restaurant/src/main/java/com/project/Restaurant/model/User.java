package com.project.Restaurant.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Document
public class User {
    @Id
    private String email;
    private String firstName;
    private String lastName;
    private String typeOfUser;
    private String password;
    private String phoneNumber;
    private String address;
    private String imgUrl;
    private Restaurant restaurants;
}
