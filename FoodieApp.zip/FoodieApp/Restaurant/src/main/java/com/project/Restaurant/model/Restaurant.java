package com.project.Restaurant.model;

import lombok.Data;

import java.util.List;
import java.util.Set;

@Data
public class Restaurant {
    String restaurantName;
    String type;
    String city;
    private String imgUrl;
    String status;
    Set<Food> foodList;
}
