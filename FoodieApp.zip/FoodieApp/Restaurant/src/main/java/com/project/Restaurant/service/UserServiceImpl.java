package com.project.Restaurant.service;

import com.project.Restaurant.exception.FoodNotFoundException;
import com.project.Restaurant.exception.RestaurantNotFoundException;
import com.project.Restaurant.exception.UserAlreadyExistException;
import com.project.Restaurant.exception.UserNotFoundException;
import com.project.Restaurant.model.Food;
import com.project.Restaurant.model.Restaurant;
import com.project.Restaurant.model.User;
import com.project.Restaurant.proxy.AdminProxy;
import com.project.Restaurant.repository.RestaurantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService{
    RestaurantRepository restaurantRepository;
    @Autowired
    AdminProxy adminProxy;
    @Autowired
    public UserServiceImpl(RestaurantRepository restaurantRepository) {
        this.restaurantRepository = restaurantRepository;
    }

    @Override
    public User registerUser(User user) throws UserAlreadyExistException {
        if (restaurantRepository.findById(user.getEmail()).isPresent()){
            throw new UserAlreadyExistException();
        }
        return restaurantRepository.save(user);
    }

    @Override
    public User addRestaurant(String email, Restaurant restaurant) throws UserNotFoundException {
        if (restaurantRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User u = restaurantRepository.findById(email).get();
        restaurant.setStatus("pending");
        u.setRestaurants(restaurant);
        restaurantRepository.save(u);
        adminProxy.addRestaurant(restaurant,email);
       return u;
    }

    @Override
    public User addFoodInRestaurant(String email, String restId, Food food) throws UserNotFoundException, RestaurantNotFoundException {
        if (restaurantRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User u = restaurantRepository.findById(email).get();

        Restaurant res = u.getRestaurants();
        if(!res.getRestaurantName().equals(restId)){
            throw new RestaurantNotFoundException();
        }

        if(res.getFoodList()==null){
//            List<Food> foodList=new ArrayList<>();
            Set<Food> foodList = new HashSet<>();
            foodList.add(food);
            res.setFoodList(foodList);
            u.setRestaurants(res);
        }
        else {
//            List<Food> foodList=res.getFoodList();
            Set<Food> foodList = res.getFoodList();
            foodList.add(food);
            res.setFoodList(foodList);
            u.setRestaurants(res);
        }
        adminProxy.addFoodInRest(food,restId,email);
        return restaurantRepository.save(u);
    }

    @Override
    public User deleteFoodInRestaurant(String email, String rName, String foodName) throws UserNotFoundException, FoodNotFoundException {
        if (restaurantRepository.findById(email).isEmpty()){
            throw new UserNotFoundException();
        }
        User u = restaurantRepository.findById(email).get();

        Restaurant res = u.getRestaurants();

//        List<Food> list = res.getFoodList();
        Set<Food> list = res.getFoodList();

        if(!list.removeIf(p->p.getFoodName().equalsIgnoreCase(foodName)))
        {
            throw new FoodNotFoundException();
        }
        res.setFoodList(list);

        u.setRestaurants(res);

        return restaurantRepository.save(u);
    }

    @Override
    public List<Restaurant> findAllCity(String city) {
        List<User> userList = restaurantRepository.findAllCity(city);
        List<Restaurant> restaurantList = userList.stream().map(p-> p.getRestaurants()).toList();
        return restaurantList;
    }

    @Override
    public User updateRestaurant(String restId, String status) {

        List<User> users = restaurantRepository.findAll();
        for (User u: users){
            System.out.println(u);
        }
        List<User> userList = users.stream().filter(p->p.getRestaurants().getRestaurantName().equalsIgnoreCase(restId)).toList();
        User user = userList.get(0);
        System.out.println(user);
        user.getRestaurants().setStatus(status);
//        Restaurant restaurant = user.getRestaurants();
//        restaurant.setStatus(true);
        return restaurantRepository.save(user);
    }

    @Override
    public User getUserDetails(String userEmail) throws UserNotFoundException {
        List<User> userList = restaurantRepository.findAll();
        User user = userList.stream().filter(p->p.getEmail().equals(userEmail)).toList().get(0);
        System.out.println(user);
        return user;
    }

}
